# AI Kids Video Maker — Starter MVP

यह project एक Android/Flutter frontend + FastAPI backend का starter है।

Flow:
Story/Text → Generate → Scene plan → Preview → MP4 export

महत्वपूर्ण:
- असली AI 3D generation के लिए image/video/voice APIs जोड़ने होंगे।
- यह starter अभी बिना paid AI API के scene plan और demo MP4 slideshow बनाता है।
- किसी copyrighted character/logo/music की copy न करें।

## Run backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

## Run Flutter
```bash
flutter pub get
flutter run
```

Backend URL को `lib/main.dart` में अपने PC के LAN IP से बदलें, जैसे:
`http://192.168.1.5:8000`

Android emulator के लिए:
`http://10.0.2.2:8000`

## Next production integrations
1. Story-to-scene LLM
2. Consistent character reference image
3. Image-to-video generation
4. TTS voice
5. Music/SFX
6. FFmpeg final rendering
7. Job queue + cloud storage
