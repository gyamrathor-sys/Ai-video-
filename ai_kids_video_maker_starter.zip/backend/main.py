from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from PIL import Image, ImageDraw, ImageFont
import os, uuid, textwrap

app = FastAPI(title="AI Kids Video Maker API")
OUT = "output"
os.makedirs(OUT, exist_ok=True)

class StoryRequest(BaseModel):
    story: str
    duration: int = 30

class Scene(BaseModel):
    number: int
    text: str
    prompt: str
    duration: int

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/generate-scenes")
def generate_scenes(req: StoryRequest):
    story = req.story.strip()
    if len(story) < 5:
        raise HTTPException(400, "Story बहुत छोटी है")

    # Demo scene splitter. Production में यहाँ LLM/scene planner जोड़ें।
    sentences = [s.strip() for s in story.replace("।", ".").split(".") if s.strip()]
    if not sentences:
        sentences = [story]

    count = min(max(len(sentences), 4), 8)
    while len(sentences) < count:
        sentences.append(sentences[-1])

    each = max(3, req.duration // count)
    scenes = []
    for i, sentence in enumerate(sentences[:count], 1):
        scenes.append({
            "number": i,
            "text": sentence,
            "prompt": (
                "Bright 3D children's animation, original characters, "
                "colorful family-friendly environment, cinematic lighting, "
                "same character design, same clothes, 16:9. Scene: " + sentence
            ),
            "duration": each
        })
    return {"scenes": scenes}

def make_demo_video(story: str, duration: int):
    # Demo MP4: colored title cards. Replace with real AI clips in production.
    from moviepy import ImageClip, concatenate_videoclips

    uid = str(uuid.uuid4())[:8]
    clips = []
    lines = [x.strip() for x in story.replace("।", ".").split(".") if x.strip()]
    if not lines:
        lines = [story]
    lines = (lines * 6)[:6]
    per = max(2, duration // len(lines))

    for i, line in enumerate(lines):
        img = Image.new("RGB", (1280, 720), (245, 238, 220))
        d = ImageDraw.Draw(img)
        title = "AI KIDS VIDEO"
        d.text((60, 50), title, fill=(40,40,40))
        wrapped = "\n".join(textwrap.wrap(line, 42))
        d.multiline_text((80, 260), wrapped, fill=(20,20,20), spacing=15)
        path = os.path.join(OUT, f"{uid}_{i}.jpg")
        img.save(path)
        clips.append(ImageClip(path).with_duration(per))

    video = concatenate_videoclips(clips, method="compose")
    out = os.path.join(OUT, f"{uid}.mp4")
    video.write_videofile(out, fps=24, codec="libx264", audio=False, logger=None)
    return out

@app.post("/generate-video")
def generate_video(req: StoryRequest):
    path = make_demo_video(req.story, req.duration)
    return {"video_url": f"/video/{os.path.basename(path)}"}

@app.get("/video/{name}")
def get_video(name: str):
    path = os.path.join(OUT, name)
    if not os.path.isfile(path):
        raise HTTPException(404, "Video नहीं मिली")
    return FileResponse(path, media_type="video/mp4", filename=name)
