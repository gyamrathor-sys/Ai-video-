import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

const backend = 'http://10.0.2.2:8000'; // Android emulator
// Physical phone: change this to your computer LAN IP, e.g. http://192.168.1.5:8000

void main() => runApp(const KidsVideoApp());

class KidsVideoApp extends StatelessWidget {
  const KidsVideoApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AI Kids Video Maker',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.pink),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final story = TextEditingController();
  bool loading = false;
  String? videoUrl;
  List scenes = [];

  Future<void> generate() async {
    if (story.text.trim().length < 5) return;
    setState(() => loading = true);
    try {
      final base = Uri.parse('$backend/generate-scenes');
      final r = await http.post(base,
        headers: {'Content-Type':'application/json'},
        body: jsonEncode({'story': story.text, 'duration': 30}));
      if (r.statusCode != 200) throw Exception(r.body);
      final data = jsonDecode(r.body);
      setState(() => scenes = data['scenes']);

      final v = await http.post(Uri.parse('$backend/generate-video'),
        headers: {'Content-Type':'application/json'},
        body: jsonEncode({'story': story.text, 'duration': 30}));
      if (v.statusCode != 200) throw Exception(v.body);
      final vd = jsonDecode(v.body);
      setState(() => videoUrl = '$backend${vd["video_url"]}');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Kids Video Maker')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text('Story लिखो', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          TextField(
            controller: story,
            maxLines: 7,
            decoration: const InputDecoration(
              hintText: 'उदाहरण: एक बच्चा पार्क में जाता है और दोस्तों के साथ खेलता है।',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: loading ? null : generate,
            icon: loading
              ? const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2))
              : const Icon(Icons.auto_awesome),
            label: Text(loading ? 'वीडियो बन रही है...' : 'Generate Full Video'),
          ),
          const SizedBox(height: 20),
          if (scenes.isNotEmpty) ...[
            const Text('Scenes', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ...scenes.map((s) => Card(
              child: ListTile(
                leading: CircleAvatar(child: Text('${s["number"]}')),
                title: Text(s["text"]),
                subtitle: Text('Duration: ${s["duration"]} sec'),
              ),
            )),
          ],
          if (videoUrl != null) ...[
            const SizedBox(height: 10),
            const Text('Preview', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            VideoPreview(url: videoUrl!),
          ]
        ],
      ),
    );
  }
}

class VideoPreview extends StatefulWidget {
  final String url;
  const VideoPreview({super.key, required this.url});
  @override State<VideoPreview> createState() => _VideoPreviewState();
}

class _VideoPreviewState extends State<VideoPreview> {
  late VideoPlayerController c;
  @override
  void initState() {
    super.initState();
    c = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) => setState(() {}));
  }
  @override
  void dispose() { c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (!c.value.isInitialized) return const Center(child:CircularProgressIndicator());
    return Column(children: [
      AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)),
      IconButton(
        icon: Icon(c.value.isPlaying ? Icons.pause : Icons.play_arrow),
        onPressed: () { setState(() => c.value.isPlaying ? c.pause() : c.play()); },
      )
    ]);
  }
}
